﻿namespace PathfindingApp
{
    // internal class Map
    // {
    // }
}